package test;

import java.time.LocalDate;

import modelo.Sistema;
import modelo.Tarea;

public class Test {

	public static void main(String[] args) {
		
		Sistema sistema = new Sistema();
		System.out.println("1)");
		sistema.agregarEmpleado("Lopez", "Martin", "3829", 400.0);
		sistema.agregarEmpleado("Rodriguez", "Lucia", "3840", 500.0);
		System.out.println("2)");
		sistema.traerEmpleado("3840");
		System.out.println("3)");
		sistema.agregarTarea("Reparaci�n Alsina altura 1500-1600", LocalDate.of(2021, 05, 25), LocalDate.of(2021,06,10), sistema.getLstEmpleados().get(0), 4, true);
		sistema.agregarTarea("Reparaci�n semaforo Alsina y Gallo", LocalDate.of(2021, 06, 21), LocalDate.of(2021,07,11), sistema.getLstEmpleados().get(1), 4, false);
		System.out.println("4)");
		sistema.traerTarea(1);
		System.out.println("5)");
		sistema.getLstTareas().get(1).calcularJornal();
	}

}
